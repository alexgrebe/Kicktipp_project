# Notes

## Bundesliga

### Two or more clubs from the same city (in Bundesliga)

**München (2)**: TSV 1860 München & FC Bayern München

**Köln (2)**: 1. FC Köln & Fortuna Köln   (in season 1973/74)

**Berlin (4)**: Herta BSC & Tennis Borussia (in season 1974/75,76/77),
Tasmania 1990 (65/66), Blau-Weiß 90 (86/87)

**Hamburg (2)**: HSV & FC St. Pauli (in season 1977/78, etc.)

**Stuttgart (2)**: VfB Stuttgart & Stuttgarter Kickers (in 88/89, 91/92)

**Bochum (2)**: VfL Bochum & Wattenscheid 09 (in 90/91, 91/92, 92/93)

